# Handoff: RareImagery — Video Valuation → Store Launch Flow (iOS)

## Overview

This is the core "first run" flow for the RareImagery iOS app (native SwiftUI, existing repo: `rareimagery-ios`). It lets a user get an item appraised by Grok Vision before creating an account, then walks them through claiming that valuation with X (Twitter) sign-in, adding their first product, and launching their store.

Four steps, in order:
1. **What's it worth?** — film an item, describe it by voice, submit → Grok Vision returns an identification + estimated value. No account required.
2. **Claim with X** — one-tap X OAuth creates the user's profile & store, importing their X photo/banner, and claims the anonymous valuation into their account.
3. **First product** — same film + voice flow, but Grok drafts a full listing (title, description, suggested price) instead of a valuation.
4. **Launch store** — edit store name/bio, reorder products, publish.

## About the Design Files

The bundled file (`design-source/RareImagery App Flow.dc.html`) is a **design reference built in HTML/React-like templating** — a clickable prototype showing intended look, copy, states, and motion. It is **not production code** and should not be embedded or copied verbatim into the app. Your task is to **recreate this design natively in SwiftUI**, inside the existing `rareimagery-ios` project, following that codebase's established patterns (see "Target codebase" below) — not to port the HTML/CSS/JS directly.

Open `design-source/RareImagery App Flow.dc.html` in a browser to interact with the live prototype (it's a self-contained file — double-click it or drag into a browser tab). Use the left-hand rail to jump between the 4 steps.

## Fidelity

**High-fidelity.** Colors, type, spacing, copy, and motion timings below are final — implement pixel-close using the equivalents already defined in the target codebase's `Theme/` folder (see Design Tokens). Where the prototype uses placeholder content (mock item name "Leica M3 Rangefinder", mock price, mock avatar image), treat the copy/structure as final but the actual data as illustrative — real screens should read from Grok Vision responses / user data.

## Target Codebase

Native iOS app at `rareimagery-ios/` (SwiftUI, zero third-party dependencies, `@Observable` for state, async/await only — no Combine). Relevant existing pieces to build on rather than duplicate:

- `RareImagery/Theme/Colors.swift` — `AppColor` enum already defines the brand palette used below (`brand`, `gold`, `vaultTop/Mid/Bottom`, `background`, `surface`, etc.) plus a `vaultGradient` and `foil` gradient. **Use these tokens directly** — don't hardcode new hex values.
- `RareImagery/Theme/Typography.swift` — `AppFont` enum defines `display()` (Space Grotesk), `bodyText()` (Hanken Grotesk), `mono()` (JetBrains Mono) helpers, with `.largeTitle/.title/.headline/.body/...` presets. Use these instead of raw `Font.custom`.
- `RareImagery/Funnel/` — `FunnelInstructionsView`, `FunnelRecordView`, `FunnelProcessingView`, `FunnelResultView`, `FunnelView` — this is the existing video-capture-to-result pipeline. **Steps 1 and 3 of this design should extend/reuse this Funnel, not be built as a new capture stack.** Add a voice-detail sub-step to the existing funnel state machine between record and processing.
- `RareImagery/OnePageCreator/` — existing product-creation flow (`OnePageCreatorView`, `OnePageCreatorViewModel`, `Components/`, `Helpers/`, `Models/`) — step 3 (First product) and step 4 (store editor/launch) should extend this rather than being new screens.
- `RareImagery/Auth/` (`SignInView`, `AuthCoordinator`) + `Packages/RareImageryAPI/Sources/RareImageryAPI/Auth/` (`AuthService`, `KeychainStore`, `PKCE`) — the X OAuth PKCE flow already exists. See `VALUE-FIRST-OAUTH.md` in the repo root for the exact anonymous-valuation → `draftToken` → claim-on-callback contract this screen (step 2) depends on. **Do not reimplement OAuth** — this design's "Claim with X" sheet is a UI treatment over the existing `AuthCoordinator`/`AuthService` calls.
- `Packages/RareImageryAPI/Sources/RareImageryAPI/Models/ProductDraft.swift` / `VisionResult.swift` — response models already include `draftToken`; the valuation result screen (below) should bind to these, not new mock models.

Anti-patterns to avoid (per the repo's own `CLAUDE.md`): don't reimplement Grok Vision logic client-side, don't write Drupal entities directly (go through the BFF), don't sign JWTs client-side, no third-party state libraries, no Combine.

## Screens / Views

### 1. Welcome (scrollable) — `isWelcome`
**Purpose:** Marketing/entry screen. Explains the app with a live demo, offers two paths: try it now, or skip straight to account creation.
**Layout:** Full-bleed scroll view, background `linear-gradient(160deg, #561F62 0%, #2C1033 40%, #160D1A 75%)` (`AppColor.vaultGradient`, roughly — check stop percentages match or adjust `vaultGradient` if needed). Three stacked sections:

**A. Hero** (padding 64/28/36/28 top/h/bottom/h):
- Bud Hound mascot image, 126×126, centered, drop shadow `0 18px 40px rgba(0,0,0,.5)`, gentle infinite breathing animation (scale 1↔1.06, opacity 1↔0.85, 5s ease-in-out loop).
- Eyebrow label: "INVITE-ONLY MARKETPLACE" — mono, 11px, `letter-spacing:.2em`, uppercase, `rgba(255,255,255,.55)`.
- Headline: "What's it worth?" — display font, 42px/700, `letter-spacing:-0.03em`, line-height 1.02, centered, two lines ("What's it" / "worth?"); the "?" is rendered in the gold foil gradient (`AppColor.foil`: `#F4E5A6 → #D4AF37 → #B8932B`, diagonal).
- Subhead: "Film any item — Grok Vision tells you what it is, and what it's worth." 14.5px, `rgba(255,255,255,.6)`, centered, max-width ~280.
- Primary button "Scan an item" — full width, 17px vertical padding, radius 16, gold gradient fill (`#F4E5A6 → #D4AF37 55% → #B8932B`, 135deg), text `#160D1A` (near-black), display font 17px/600, shadow `0 8px 28px rgba(212,175,55,.28)`. Press state: `translateY(1px) scale(.99)`.
- Caption under button: "No account needed — value first." 12.5px, `rgba(255,255,255,.4)`.
- Scroll affordance: small "SEE HOW IT WORKS" mono label + bouncing chevron-down, 50% opacity, pulses (same breathing animation, 1.8s).
- **Action:** taps "Scan an item" → navigates to **Camera** screen in `value` mode.

**B. Demo section** (below a hairline border, background `rgba(0,0,0,.16)` tint):
- Eyebrow "DEMO" (gold, mono, 10px, wide tracking), heading "From video to value" (20px/700, centered).
- Three-step vertical timeline connected by 1px vertical connector lines (18px tall, `rgba(255,255,255,.15)`, left-aligned under the 64px icon column):
  1. **Capture** — 64×64 rounded tile (gradient `#3a2444→#1c1122`, gold-tinted border) containing a play-button glyph (26px gold circle + white triangle) and a small pulsing red "recording" dot top-right. Text: "Someone films a product" / "A quick pan around a vintage camera."
  2. **Analyze** — 64×64 tile, gold-tinted spinner (22px, 1s linear infinite rotation). Text: "Grok Vision analyzes it" / "Identifies the item and researches comparables."
  3. **Result card** — bordered card (gold hairline `rgba(212,175,55,.4)`, radius 18, padding 18):
     - Row: 52×52 image placeholder tile + item title "Leica M3 Rangefinder" (16.5px/600) + subtitle "Double-stroke · c. 1958 · body only" (12px, muted).
     - Description line, 13px, `rgba(255,255,255,.6)`: one sentence of Grok reasoning.
     - Bottom row: "ESTIMATED VALUE" mono label (9.5px) above a large gold-gradient-text price "$1,800–2,400" (26px/700 display font, gradient-clipped text) on the left; a solid-gold pill badge **"SELL THIS"** on the right (mono, 10.5px, bold, `#160D1A` text on gold gradient fill, fully rounded).

**C. Create-account CTA** (bottom section):
- Heading "Ready to sell yours?" (19px/700), subtext "Create your account with X — it takes one tap." (13px, muted).
- Button "Create account with 𝕏" — full width, white fill, black text, 16px/700, fully rounded corners (pill-ish radius 16), same press-scale interaction.
- **Action:** → navigates directly to **X Auth** sheet (skips the demo — this is the "just sign me up" shortcut).

### 2. Camera capture — `isCamera` (used for both step 1 "value" mode and step 3 "product" mode)
**Purpose:** Record a short video of the item; frames are extracted live as thumbnails.
**Layout:** Full-bleed dark viewfinder background (radial gradient `#2a1c31 → #140c18 → #08050a`), faint horizontal scanline texture overlay for a camera-grain feel.
- Dashed gold guide frame (`1.5px dashed rgba(212,175,55,.55)`, radius 22) roughly centered, inset 44px sides / 190px top / 290px bottom — this is where the subject should sit.
- Hint pill top area ("Frame your item" idle / "Slowly pan around the item" while recording), mono-ish pill, blurred dark background.
- While recording: a horizontal gold scanline sweeps top-to-bottom-to-top inside the guide frame on a 3.2s loop (subtle "scanning" cue). A "REC 0:0X" pill appears top with a blinking red dot (1.1s blink).
- Live filmstrip: as recording progresses, small 48×64 rounded thumbnails fade/slide in above the controls (max 4 shown), one roughly every ~0.9s of recording, each captioned "F01, F02…". Caption under filmstrip while recording: "CAPTURING FRAMES FOR GROK VISION" (mono, gold, uppercase).
- Bottom controls: ✕ cancel button (left, 48px circle, translucent), record button (center, 80px circle):
  - **Idle:** white ring border, brand-gold gradient disc inside showing the **app mascot/logo** (not a plain red dot — this was an explicit revision from a generic record dot to the Bud Hound mark).
  - **Recording:** ring turns red, inner shape morphs from circle to rounded-square (standard iOS record-button convention), same logo still visible inside at reduced fill.
  - Helper caption below: "Step 1 of 3 · Tap to record a short video" idle → "Tap to stop — next: add details by voice" while recording.
- Recording auto-stops at 5 seconds in the prototype (production: use whatever max-duration the Funnel's existing capture logic uses).
- **Action:** stop recording → advances to **Voice Details** screen, carrying the captured frame thumbnails forward.

### 3. Voice details — `isVoice`
**Purpose:** Let the user add spoken context (condition, age, provenance) that Grok folds into its analysis. **This is a new explicit step requested by the client — insert it between capture and processing in the existing Funnel state machine.**
**Layout:** Scrollable column, dark purple gradient background, padding ~84/24/44.
- "STEP 2 OF 3" eyebrow (mono, centered), heading "Tell us about it" (26px/700, centered), subhead "Age, condition, provenance — anything helps Grok price it." (13.5px, centered, muted).
- Row of the captured frame thumbnails from the previous screen (44×64, smaller than the capture-screen versions), centered.
- Large mic button (84px circle): idle = subtle translucent white fill/border; while listening = gold border + gold-tinted glow (`box-shadow 0 0 34px rgba(212,175,55,.35)`) + gold mic-icon stroke. A small animated equalizer (6 vertical gold bars, varying heights, independently pulsing) appears under the button only while listening.
- Hint label under the mic: "Tap to speak" → "Listening… tap to stop" → "Tap to re-record" (mono, uppercase, small).
- Once any speech is captured, a transcript card appears: "TRANSCRIPT" eyebrow + the recognized text in quotes, 14px, `rgba(255,255,255,.8)`, in a soft bordered card.
- Primary button pinned to bottom: label is "Submit video only" until a transcript exists, then becomes "Submit to Grok" — same gold-gradient button style as elsewhere. Dims to ~45% opacity while actively recording (can't submit mid-recording).
- Secondary link below: "Skip — submit video only" (plain text button) — lets the user bypass voice entirely.
- **Action:** submit or skip → advances to **Analyzing** screen.

**Implementation note:** in production this is a real Speech-to-Text capture (e.g. `SFSpeechRecognizer`), not simulated typing. The prototype fakes a transcript appearing word-by-word to preview the interaction; the actual behavior should stream real partial-recognition results the same way.

### 4. Analyzing (processing) — `isAnalyzing`
**Purpose:** Loading state while the video + transcript are uploaded and Grok Vision processes them. Reuses `FunnelProcessingView`'s slot in the state machine but needs the mascot animation described below.
**Layout:** Centered column, dark gradient background.
- 170×170 mascot artwork with a **custom animated moment**: a subtle "puffing" idle loop (gentle scale/lift bob, ~3.6s cycle) combined with a small glowing ember dot near the character's hand/mouth and 2–3 staggered soft "smoke puff" blobs that fade-and-rise-and-scale on loop, gold-tinted spinner ring around the whole mascot (1.3s rotation).
- Title: "Appraising…" (value mode) or "Drafting your listing…" (product mode), 24px/700.
- Step label cycles through 4 phases tied to progress (mono, gold, uppercase, ~11px): e.g. "UPLOADING FRAMES + VOICE" → "GROK VISION · IDENTIFYING" → "RESEARCHING COMPARABLES" → "ESTIMATING VALUE" (value mode) or "…WRITING TITLE + DESCRIPTION" → "…SUGGESTING PRICE" (product mode).
- Thin progress bar (260px max width, 4px tall, fully rounded), gold gradient fill animating 0→100%.
- Footnote: "Bud Hound is sniffing out {N} frames + your voice note…" (only mentions the voice note if one was captured).
- Auto-advances to **Valuation Result** (value mode) or **Product Draft** (product mode) when complete.

### 5. Valuation result — `isValuation`
**Purpose:** Show the Grok Vision identification + estimated value; offer to claim it.
**Layout:** Scrollable column, padding ~84/22/40.
- Eyebrow "GROK VISION · RESULT" centered.
- Result card (gold hairline border, radius 20, soft outer gold glow):
  - Header row: 64×64 hero image + item title (19px/600) + one-line specifics (13px, muted).
  - "ESTIMATED VALUE" eyebrow → large price range in gold-gradient text, 44px/700 (e.g. "$1,800–2,400").
  - Two pill badges: confidence percentage (e.g. "87% CONFIDENCE", gold-tinted) and a rarity tag ("RARE", neutral).
  - Divider, then 2–3 sentences of reasoning/comparables in body text, 13.5px, muted.
- Primary button "Claim this valuation" (gold gradient, same style as elsewhere).
- Caption: "Sign in with X to save it — and open your store." (13px, muted).
- Secondary text link: "Scan another item" (loops back to Camera).
- **Action:** Claim → **X Auth** sheet.

### 6. X Auth (claim) — `isXAuth`
**Purpose:** X OAuth consent, presented as a bottom sheet, that also communicates the account/store creation side-effects.
**Layout:** Full-screen dimmed scrim (`rgba(0,0,0,.5)`) behind a bottom sheet (black fill, top corners radius 24, slide-up entrance).
- Grab handle bar (38×4, rounded, translucent), centered.
- Header row: X logo mark (44×44 white rounded-square tile with the 𝕏 glyph) + "Authorize RareImagery" (16px/600) + "x.com wants to sign you in" (13px, muted).
- Identity preview card: circular avatar (38px) + display name "Bud Hound" + "@handle" in mono — this previews the X identity being connected.
- Disclosure copy (12.5px, muted): "RareImagery will create your profile & store at **{handle}.rareimagery.net**, import your X photo & banner, and claim your saved valuation." (the store URL is highlighted in gold mono).
- Two states:
  - **Idle:** "Authorize app" button (white fill, black text, fully pill-rounded, 16px/700) + "Cancel" text link below.
  - **Connecting** (after tap): button row replaced by a centered spinner + "Creating your store…" (14px).
- **Action:** on success → **Store Created** screen.

**Implementation note:** this maps directly onto the existing `VALUE-FIRST-OAUTH.md` contract — `ASWebAuthenticationSession` PKCE flow via `AuthCoordinator`, with the anonymous valuation's `draftToken` passed through `POST /api/mobile/auth/x/callback` to claim it server-side. The "creating your store" spinner state corresponds to waiting on that callback + claim round-trip.

### 7. Store created — `isStoreCreated`
**Purpose:** Confirms the account/store now exists and the valued item has been claimed into it; prompts adding a first product.
**Layout:** Centered-top column, padding ~96/26/44.
- Circular avatar (76px) with gold ring + glow — imported X profile photo.
- Headline "Your store is ready." (34px/700, "." rendered in gold foil).
- Store URL in gold mono (e.g. "budhound.rareimagery.net").
- Caption: "Profile photo & banner imported from @handle." (12.5px, muted).
- "CLAIMED TO YOUR VAULT" eyebrow, then a product row card showing the just-claimed item (thumbnail, name, value, and a green "CLAIMED" status pill).
- Primary button "Add your first product" (gold gradient).
- Caption: "Film it — Grok writes the listing for you." (13px, muted).
- **Action:** → **Camera** screen in `product` mode.

### 8. Product draft — `isProductDraft`
**Purpose:** Editable Grok-generated listing after filming a product to sell.
**Layout:** Scrollable column, plain dark background (`#160D1A`), padding ~78/22/40.
- Header row: "New listing" (24px/700) + a "GROK DRAFT" pill badge (purple-tinted, mono, uppercase) signaling AI-generated content that needs review.
- Row of 3 captured-frame thumbnails (82×82), the first marked with a small gold "HERO" tag (top-right) indicating it's the selected cover image.
- Editable fields, each preceded by a mono uppercase label:
  - **Title** — single-line text input.
  - **Description** — 3-row textarea.
  - **Price** — narrow currency input (~120px, gold mono text) + inline helper text "Grok suggests $58–72 from comparables".
- Primary button "Add to my store" (gold gradient).
- Secondary text link "Re-film item" (loops back to Camera in product mode).
- **Action:** → **Store Editor**.

### 9. Store editor — `isStoreEditor`
**Purpose:** Final review/edit of the storefront before going live. **Per latest client direction: no theme picker** — the storefront's look & feel comes entirely from the imported X profile (avatar + banner), not a selectable theme.
**Layout:** Fixed header + scrollable middle + pinned bottom action bar.
- Header row: "Your store" (24px/700) + "DRAFT" status label (mono, muted).
- Banner + avatar block: 96px-tall banner (brand gradient placeholder, labeled "BANNER · IMPORTED FROM X" — this is pulled from the user's X banner, not editable here), with a 60px circular avatar overlapping the bottom-left corner (gold ring), and a small "@handle · SYNCED FROM X" caption bottom-right. **No upload/replace affordance — these are read-only, sourced from X.**
- Editable store name (single-line input, 16px/600 display font) and bio (single-line input, 13.5px) — both directly under the banner.
- "PRODUCTS · DRAG ORDER" section: list of product rows (thumbnail + name + price), each with up/down reorder buttons (▲/▼) on the right (prototype uses tap-to-reorder buttons rather than drag; real implementation should use a native SwiftUI drag-to-reorder list if feasible).
- Bottom bar (pinned, translucent blurred background): "Launch store" button (gold gradient) → while launching, replaced with a spinner + "Publishing to {url}…".
- **Action:** Launch → **Launched** screen.

### 10. Launched — `isLaunched`
**Purpose:** Success/confirmation screen.
**Layout:** Centered column, celebratory framing.
- Mascot artwork (150px), radial gold glow behind it.
- "STORE № 001 · LIVE" eyebrow.
- Big headline "You're live." (56px/700, "." in gold foil).
- Store URL in gold mono.
- Two buttons side by side: "Replay flow" (outline/ghost, loops back to Welcome) and "Open store" (gold gradient, primary — real implementation should deep-link to the storefront web view or Safari).
- Footer wordmark: "Be Rare." (14px/600, muted, brand tagline — per design system voice this is the fixed brand sign-off, always exactly this two-word phrase with period).

## Interactions & Behavior

- **Navigation model:** linear forward flow with a couple of loop-backs (scan-another-item, re-film). No tab bar in this flow — treat it as a modal/full-screen flow (likely presented from a "+" or onboarding entry point elsewhere in the app), matching how `FunnelView`/`OnePageCreatorView` are already presented.
- **Recording:** tap-to-start/tap-to-stop (not press-and-hold). Max duration in prototype is simulated at 5s; use the real Funnel capture's existing duration limit.
- **Voice capture:** tap-to-start/tap-to-stop toggle on the mic button; streams a live transcript. Button dims and is disabled mid-recording.
- **Processing / analyzing:** determinate progress bar with 4 discrete phase labels (25% increments); real implementation should map actual upload/API-call phases to these labels rather than a fake timer, but keep the 4-phase structure and copy tone.
- **X Auth:** standard `ASWebAuthenticationSession` PKCE round trip; sheet shows a connecting/spinner state for the duration of the network call, not a fixed delay.
- **All primary CTAs** share one press interaction: `translateY(1px) scale(0.99)` on press — implement as a `.scaleEffect`/`.offset` change bound to a `@GestureState` press flag, ~100–150ms.
- **Mascot animations** (see Design Tokens → Motion) are the one place this design uses decorative looping animation; everything else is either a one-shot transition or tied to real async state (spinners, progress).

## State Management

Minimal state per step — this maps naturally onto whatever `@Observable` view models the existing `FunnelViewModel`/`OnePageCreatorViewModel`-equivalent already track. Key pieces of state referenced by this design:

- Current step/screen enum (welcome, camera, voice, analyzing, valuation, xAuth, storeCreated, productDraft, storeEditor, launched).
- Capture mode: `value` (anonymous appraisal) vs `product` (authenticated listing creation) — same camera/voice/analyzing UI, different copy and different downstream screen.
- Captured frame thumbnails (array), recording flag + elapsed seconds.
- Voice: recording flag, transcript string (built incrementally from live speech recognition).
- Analysis: progress percentage, derived phase label.
- Valuation result: item title, subtitle, image, price range, confidence %, rarity tag, reasoning text — bind to the real `VisionResult`/`ProductDraft` model.
- Auth: connecting flag; on success, the claimed draft + new store URL + imported X handle/avatar/banner.
- Product draft: editable title/description/price strings, seeded from Grok's suggestion.
- Store editor: editable name/bio strings, ordered product list; launching flag.

## Design Tokens

**Colors** — map to `AppColor` in `Theme/Colors.swift` (already defined; use these, don't hardcode):
- Brand purple: `#7B2D8E` → `AppColor.brand`
- Brand gold: `#D4AF37` → `AppColor.gold`; deeper gold for text-on-light `#B8932B` → `AppColor.gold700`
- Gold foil gradient (headline accents): `#F4E5A6 → #D4AF37 → #B8932B` diagonal → `AppColor.foil`
- Vault background gradient stops: `#561F62 (top) → #2C1033 (mid) → #160D1A (bottom)` → `AppColor.vaultTop/vaultMid/vaultBottom` / `AppColor.vaultGradient`
- Base background: `#100912` / `#160D1A` (slightly different darks used interchangeably across screens — treat as the same "ink" surface)
- Card/surface fill: `rgba(255,255,255,.04–.06)` translucent white over dark backgrounds
- Borders: default hairline `rgba(255,255,255,.08–.12)`; gold/"rare" hairline `rgba(212,175,55,.3–.5)`
- Success/claimed: `#3FB950` (green pill)
- Destructive/recording: `#ff3b30` (iOS system red, used for the record dot/ring only)
- Text: primary white, secondary `rgba(255,255,255,.5–.65)`, tertiary `rgba(255,255,255,.35–.45)`

**Typography** — map to `AppFont` in `Theme/Typography.swift`:
- Display (Space Grotesk) for all headlines, buttons, section titles — weights 600–700, tight tracking (`-0.01` to `-0.03em`) at large sizes.
- Body (Hanken Grotesk) for descriptions, captions, form values.
- Mono (JetBrains Mono) for eyebrows/labels, prices where called out, badges, status pills — always uppercase with wide tracking (`~0.1–0.2em`) for eyebrow-style labels.

**Spacing/Radius** — no formal scale enforced in the prototype beyond what's noted per-screen above; follow the repo's existing spacing constants if one exists, otherwise treat 16px as the standard card/button radius, 20–24px for large sheets/cards, and full-round (999px) for pills/badges/circular buttons.

**Motion:**
- Standard button press: `translateY(1px) scale(.99)`, ~100–150ms.
- Screen-enter fade+rise (used on most screens except the busy Welcome screen, see note below): opacity 0→1 + translateY 10px→0, 0.35–0.5s ease-out.
- Mascot idle "breathing": scale 1↔1.06, opacity 1↔0.85, 5s ease-in-out infinite (Welcome, Launched screens).
- Mascot "puffing" idle (Analyzing screen only): scale/lift bob ~3.6s cycle + glowing ember dot (opacity/box-shadow pulse) + 2–3 staggered soft blurred circles that fade in, drift up-and-left, and scale up before fading out, looped and staggered ~1.2s apart.
- Spinners: simple 360° rotation, 0.8–1.3s linear infinite, gold-on-transparent ring.
- Recording indicator: blinking dot, 1.1s opacity pulse (1 ↔ 0.25).
- Scanline sweep (camera guide frame while recording): a horizontal gold line travels top↔bottom inside the guide frame, 3.2s ease-in-out infinite.
- Voice equalizer bars: independent height-pulse per bar, 0.45–0.7s each, slightly offset durations for a natural "talking" look.

**⚠️ Known bug/gotcha to avoid:** on the Welcome screen specifically, a one-shot fade-in entrance animation combined with several concurrent infinite child animations (mascot breathing, blinking dot, spinner, chevron pulse) caused the whole screen to render permanently at `opacity: 0` in the HTML prototype (the one-shot animation never settled). It was fixed by removing the entrance animation from that specific screen only. If you see something in SwiftUI render at 0 opacity indefinitely, check for a similar multiple-concurrent-animation conflict — don't assume it's an intentional part of this spec.

## Assets

- `design-source/assets/budhound.png` — the "Bud Hound" mascot artwork (user-supplied, transparent PNG, 400×400). Used as: hero mascot (Welcome, Analyzing, Launched screens), record-button glyph (replacing a generic dot), and as a stand-in for the user's imported X profile photo in mockups (X Auth sheet, Store Created, Store Editor — **in production this is the user's real X avatar, not the mascot**; the mascot only belongs in the marketing/mascot moments, not as a literal avatar placeholder).
- No icon font/SVG icon set was used beyond a few inline SVGs (mic icon, back-chevron, scroll-chevron, wifi/battery/signal status glyphs) — recreate with SF Symbols where a native equivalent exists (e.g. mic icon → `mic.fill`).
- Status bar / device chrome shown in the prototype (time, signal, wifi, battery, dynamic island) is scaffolding from a generic iOS mockup frame — ignore entirely; the real app runs in an actual device chrome.

## Files

- `design-source/RareImagery App Flow.dc.html` — the full interactive prototype (open in any browser). Contains all 10 screens described above plus a left-hand "flow rail" for jumping between steps (that rail is dev/review scaffolding only, not part of the app design).
- `design-source/assets/budhound.png` — mascot artwork asset.

## Questions for the design owner (flag before build)

- Confirm exact max recording duration for capture (prototype simulates 5s).
- Confirm whether product reordering in the Store Editor should be native drag-and-drop vs the up/down buttons shown in the prototype (recommended: native drag for a real app).
- Confirm the "Open store" button on the Launched screen's destination (in-app web view vs Safari vs a native store-preview screen).
