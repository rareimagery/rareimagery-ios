/* @ds-bundle: {"format":3,"namespace":"RareImageryDesignSystem_12274b","components":[{"name":"EditionTag","sourcePath":"components/brand/EditionTag.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Avatar","sourcePath":"components/data/Avatar.jsx"},{"name":"Card","sourcePath":"components/data/Card.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/brand/EditionTag.jsx":"e5a23b05e994","components/core/Badge.jsx":"efc98e5ddad6","components/core/Button.jsx":"154beb8eeb8c","components/data/Avatar.jsx":"53b5676fb304","components/data/Card.jsx":"8b5bced8174b","components/forms/Input.jsx":"0043d5d39f16","components/forms/Switch.jsx":"f04f56d84168","components/navigation/Tabs.jsx":"57841dc4c517","ui_kits/storefront/CreatorStore.jsx":"d8946ff8740a","ui_kits/storefront/DiscoverScreen.jsx":"06893da1d882","ui_kits/storefront/ProductDetail.jsx":"3c6291a808a2","ui_kits/storefront/StorePlayer.jsx":"06b77d42b2e2","ui_kits/storefront/TopNav.jsx":"8adfd07c6233","ui_kits/storefront/kit.jsx":"cd18d4189c3a","ui_kits/studio/ios-frame.jsx":"be3343be4b51","ui_kits/studio/screens.jsx":"8c448592aaf4"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.RareImageryDesignSystem_12274b = window.RareImageryDesignSystem_12274b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/EditionTag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * EditionTag — the signature RareImagery "catalog code" chip. Mono, uppercase,
 * with a gold hairline. Use it to make products/creators feel collectible:
 * an edition number, a drop code, a serial.
 */
function EditionTag({
  code,
  total,
  label = 'EDITION',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '8px',
      padding: '5px 10px',
      borderRadius: 'var(--radius-sm)',
      background: 'color-mix(in srgb, var(--gold-500) 8%, var(--surface-raised))',
      border: '1px solid var(--border-gold)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--tracking-wide)',
      textTransform: 'uppercase',
      color: 'var(--text)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--gold-700)',
      fontWeight: 700
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 1,
      height: 12,
      background: 'var(--border-gold)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700
    }
  }, "\u2116 ", code), total != null && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-subtle)'
    }
  }, "/ ", total));
}
Object.assign(__ds_scope, { EditionTag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/EditionTag.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tones = {
  neutral: {
    bg: 'var(--surface-sunken)',
    fg: 'var(--text-muted)',
    bd: 'var(--border)'
  },
  brand: {
    bg: 'var(--brand-soft)',
    fg: 'var(--brand)',
    bd: 'color-mix(in srgb, var(--brand) 25%, transparent)'
  },
  gold: {
    bg: 'var(--gold-soft)',
    fg: 'var(--gold-700)',
    bd: 'var(--border-gold)'
  },
  success: {
    bg: 'var(--success-soft)',
    fg: 'var(--success-600)',
    bd: 'color-mix(in srgb, var(--success-500) 30%, transparent)'
  },
  warning: {
    bg: 'var(--warning-soft)',
    fg: 'var(--warning-600)',
    bd: 'color-mix(in srgb, var(--warning-500) 30%, transparent)'
  },
  danger: {
    bg: 'var(--danger-soft)',
    fg: 'var(--danger-600)',
    bd: 'color-mix(in srgb, var(--danger-500) 30%, transparent)'
  }
};
function Badge({
  children,
  tone = 'neutral',
  solid = false,
  dot = false,
  style,
  ...rest
}) {
  const t = tones[tone] || tones.neutral;
  const base = solid ? {
    background: t.fg,
    color: 'var(--neutral-0)',
    border: '1px solid transparent'
  } : {
    background: t.bg,
    color: t.fg,
    border: `1px solid ${t.bd}`
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      padding: '3px 10px',
      borderRadius: 'var(--radius-pill)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      fontWeight: 600,
      lineHeight: 1.4,
      letterSpacing: 'var(--tracking-snug)',
      whiteSpace: 'nowrap',
      ...base,
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'currentColor'
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizes = {
  sm: {
    padding: '7px 14px',
    fontSize: 'var(--text-sm)',
    gap: '6px',
    height: 34
  },
  md: {
    padding: '10px 20px',
    fontSize: 'var(--text-md)',
    gap: '8px',
    height: 42
  },
  lg: {
    padding: '14px 28px',
    fontSize: 'var(--text-lg)',
    gap: '10px',
    height: 52
  }
};
function variantStyle(variant) {
  switch (variant) {
    case 'gold':
      return {
        background: 'var(--gold)',
        color: 'var(--text-on-gold)',
        border: '1px solid transparent',
        fontWeight: 700,
        boxShadow: 'var(--shadow-sm)',
        '--hov': 'var(--gold-hover)'
      };
    case 'secondary':
      return {
        background: 'var(--surface-raised)',
        color: 'var(--text)',
        border: '1px solid var(--border-strong)',
        fontWeight: 600,
        '--hov': 'var(--surface-sunken)'
      };
    case 'ghost':
      return {
        background: 'transparent',
        color: 'var(--text)',
        border: '1px solid transparent',
        fontWeight: 600,
        '--hov': 'var(--surface-sunken)'
      };
    case 'primary':
    default:
      return {
        background: 'var(--brand)',
        color: 'var(--brand-contrast)',
        border: '1px solid transparent',
        fontWeight: 600,
        boxShadow: 'var(--shadow-brand)',
        '--hov': 'var(--brand-hover)'
      };
  }
}
function Button({
  children,
  variant = 'primary',
  size = 'md',
  leftIcon,
  rightIcon,
  disabled = false,
  fullWidth = false,
  type = 'button',
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const s = sizes[size] || sizes.md;
  const v = variantStyle(variant);
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: s.gap,
    padding: s.padding,
    fontSize: s.fontSize,
    minHeight: s.height,
    fontFamily: 'var(--font-display)',
    letterSpacing: 'var(--tracking-snug)',
    borderRadius: 'var(--radius-md)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    width: fullWidth ? '100%' : 'auto',
    whiteSpace: 'nowrap',
    transition: 'background var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out)',
    transform: active ? 'translateY(1px) scale(0.99)' : 'none',
    opacity: disabled ? 0.45 : 1,
    ...v,
    background: hover && !disabled && v['--hov'] ? v['--hov'] : v.background,
    ...style
  };
  delete base['--hov'];
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    style: base,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false)
  }, rest), leftIcon, children, rightIcon);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/data/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const dims = {
  xs: 24,
  sm: 32,
  md: 44,
  lg: 64,
  xl: 96
};
function Avatar({
  src,
  name = '',
  size = 'md',
  ring = false,
  square = false,
  style,
  ...rest
}) {
  const d = dims[size] || dims.md;
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: d,
      height: d,
      flexShrink: 0,
      borderRadius: square ? 'var(--radius-md)' : '50%',
      background: 'var(--brand-soft)',
      color: 'var(--brand)',
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: d * 0.36,
      letterSpacing: '-0.02em',
      overflow: 'hidden',
      boxShadow: ring ? '0 0 0 2px var(--bg), 0 0 0 4px var(--gold)' : 'none',
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials || '·');
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  children,
  featured = false,
  interactive = false,
  padding = 'var(--space-5)',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => interactive && setHover(true),
    onMouseLeave: () => interactive && setHover(false),
    style: {
      background: 'var(--surface-raised)',
      border: featured ? '1px solid var(--border-gold)' : '1px solid var(--border)',
      borderRadius: 'var(--radius-card)',
      padding,
      boxShadow: featured ? 'var(--glow-gold)' : hover ? 'var(--shadow-lg)' : 'var(--shadow-sm)',
      transform: hover ? 'translateY(-3px)' : 'none',
      transition: 'transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)',
      cursor: interactive ? 'pointer' : 'default',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Card.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  leftIcon,
  prefix,
  type = 'text',
  size = 'md',
  id,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const autoId = React.useId();
  const fieldId = id || autoId;
  const pad = size === 'lg' ? '13px 14px' : size === 'sm' ? '7px 11px' : '10px 13px';
  const fs = size === 'lg' ? 'var(--text-lg)' : size === 'sm' ? 'var(--text-sm)' : 'var(--text-md)';
  const borderColor = error ? 'var(--danger-500)' : focus ? 'var(--brand)' : 'var(--border-strong)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      width: '100%'
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      fontWeight: 600,
      color: 'var(--text)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      background: 'var(--surface-raised)',
      border: `1px solid ${borderColor}`,
      borderRadius: 'var(--radius-md)',
      padding: pad,
      boxShadow: focus ? '0 0 0 3px var(--focus-ring)' : 'none',
      transition: 'border-color var(--dur-fast), box-shadow var(--dur-fast)'
    }
  }, leftIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-subtle)',
      display: 'inline-flex'
    }
  }, leftIcon), prefix && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-subtle)'
    }
  }, prefix), /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    type: type,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-body)',
      fontSize: fs,
      color: 'var(--text)',
      minWidth: 0,
      ...style
    }
  }, rest))), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: error ? 'var(--danger-600)' : 'var(--text-subtle)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  checked = false,
  onChange,
  disabled = false,
  label,
  id,
  style,
  ...rest
}) {
  const autoId = React.useId();
  const fieldId = id || autoId;
  const track = checked ? 'var(--brand)' : 'var(--neutral-300)';
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", _extends({
    id: fieldId,
    role: "switch",
    "aria-checked": checked,
    type: "button",
    disabled: disabled,
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 44,
      height: 26,
      borderRadius: 'var(--radius-pill)',
      background: track,
      border: 'none',
      padding: 3,
      cursor: 'inherit',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: checked ? 'flex-end' : 'flex-start',
      transition: 'background var(--dur-base) var(--ease-out)'
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: '50%',
      background: 'var(--neutral-0)',
      boxShadow: 'var(--shadow-sm)',
      transition: 'transform var(--dur-base) var(--ease-spring)'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text)'
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tabs({
  tabs = [],
  value,
  onChange,
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(tabs[0] && tabs[0].id);
  const active = value !== undefined ? value : internal;
  const select = id => {
    if (value === undefined) setInternal(id);
    onChange && onChange(id);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: 'inline-flex',
      gap: '2px',
      padding: '4px',
      background: 'var(--surface-sunken)',
      borderRadius: 'var(--radius-md)',
      border: '1px solid var(--border)',
      ...style
    }
  }, rest), tabs.map(t => {
    const on = t.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      role: "tab",
      "aria-selected": on,
      type: "button",
      onClick: () => select(t.id),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: '7px',
        padding: '7px 16px',
        border: 'none',
        cursor: 'pointer',
        borderRadius: 'var(--radius-sm)',
        fontFamily: 'var(--font-display)',
        fontSize: 'var(--text-sm)',
        fontWeight: 600,
        letterSpacing: 'var(--tracking-snug)',
        background: on ? 'var(--surface-raised)' : 'transparent',
        color: on ? 'var(--text)' : 'var(--text-subtle)',
        boxShadow: on ? 'var(--shadow-sm)' : 'none',
        transition: 'all var(--dur-fast) var(--ease-out)'
      }
    }, t.icon, t.label, t.count != null && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-2xs)',
        padding: '1px 6px',
        borderRadius: 'var(--radius-pill)',
        background: on ? 'var(--brand-soft)' : 'var(--surface-raised)',
        color: on ? 'var(--brand)' : 'var(--text-subtle)'
      }
    }, t.count));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/storefront/CreatorStore.jsx
try { (() => {
// Creator storefront — a single creator's store with StorePlayer + product grid.
function CreatorStore({
  creatorId = 'budhound',
  onOpenProduct,
  onBack
}) {
  const {
    Button,
    Badge,
    Card,
    Avatar,
    EditionTag,
    Tabs
  } = window.RareImageryDesignSystem_12274b;
  const {
    ArtTile,
    CREATORS,
    PRODUCTS,
    StorePlayer
  } = window;
  const [following, setFollowing] = React.useState(false);
  const [tab, setTab] = React.useState('shop');
  const c = CREATORS.find(x => x.id === creatorId) || CREATORS[0];
  const items = PRODUCTS.filter(p => p.creator === c.name);
  const list = items.length ? items : PRODUCTS.slice(0, 3);
  const I = ({
    n,
    s = 16
  }) => /*#__PURE__*/React.createElement("i", {
    "data-lucide": n,
    style: {
      width: s,
      height: s
    }
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1180,
      margin: '0 auto',
      padding: '20px 28px 64px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      border: 'none',
      background: 'transparent',
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(I, {
    n: "chevron-left"
  }), " Discover"), /*#__PURE__*/React.createElement("div", {
    className: "ri-grain",
    style: {
      position: 'relative',
      height: 150,
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
      background: `linear-gradient(120deg, ${c.theme}, var(--ink-900))`
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 18,
      margin: '-44px 0 24px',
      padding: '0 8px',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: c.name,
    size: "xl",
    ring: true,
    style: {
      width: 96,
      height: 96,
      fontSize: 34,
      boxShadow: '0 0 0 4px var(--bg)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      paddingBottom: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 30
    }
  }, c.name), c.verified && /*#__PURE__*/React.createElement(Badge, {
    tone: "gold",
    dot: true
  }, "Verified")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-subtle)',
      marginTop: 4
    }
  }, c.handle, " \xB7 ", c.followers, " followers \xB7 rareimagery.net/", c.id)), /*#__PURE__*/React.createElement(Button, {
    variant: following ? 'secondary' : 'primary',
    leftIcon: /*#__PURE__*/React.createElement(I, {
      n: following ? 'check' : 'plus'
    }),
    onClick: () => setFollowing(f => !f)
  }, following ? 'Following' : 'Follow')), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 320px',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    tabs: [{
      id: 'shop',
      label: 'Shop',
      count: list.length
    }, {
      id: 'about',
      label: 'About'
    }],
    style: {
      marginBottom: 18
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2, 1fr)',
      gap: 18
    }
  }, list.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.id,
    interactive: true,
    featured: p.rare,
    padding: "0",
    onClick: () => onOpenProduct(p.id),
    style: {
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(ArtTile, {
    seed: p.seed,
    ratio: "1 / 1",
    radius: "0",
    label: p.title.split(' ')[0]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 14px 14px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 15
    }
  }, p.title), /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral",
    style: {
      marginTop: 6
    }
  }, p.tag)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      color: 'var(--gold-700)'
    }
  }, "$", p.price)))))), /*#__PURE__*/React.createElement("aside", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18,
      position: 'sticky',
      top: 80
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ri-eyebrow",
    style: {
      marginBottom: 8
    }
  }, "STORE PLAYER"), /*#__PURE__*/React.createElement(StorePlayer, {
    track: "Hound Beats \u2014 Intro",
    artist: c.name,
    accent: "#D4AF37"
  })), /*#__PURE__*/React.createElement(Card, {
    padding: "var(--space-4)"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ri-eyebrow",
    style: {
      marginBottom: 10
    }
  }, "STORE"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, "Theme"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600
    }
  }, "Vault (dark)")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, "Products"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600
    }
  }, list.length)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, "Since"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600
    }
  }, "2024")))))));
}
window.CreatorStore = CreatorStore;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/CreatorStore.jsx", error: String((e && e.message) || e) }); }

// ui_kits/storefront/DiscoverScreen.jsx
try { (() => {
// Discover — marketplace home.
function DiscoverScreen({
  onOpenStore,
  onOpenProduct
}) {
  const {
    Button,
    Badge,
    Card,
    Avatar,
    EditionTag,
    Tabs
  } = window.RareImageryDesignSystem_12274b;
  const {
    ArtTile,
    CREATORS,
    PRODUCTS
  } = window;
  const [filter, setFilter] = React.useState('all');
  const I = ({
    n,
    s = 18
  }) => /*#__PURE__*/React.createElement("i", {
    "data-lucide": n,
    style: {
      width: s,
      height: s
    }
  });
  const shown = PRODUCTS.filter(p => filter === 'all' || p.tag.toLowerCase() === filter);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    className: "ri-grain",
    style: {
      position: 'relative',
      overflow: 'hidden',
      background: 'var(--brand-wash)',
      padding: '64px 28px 72px',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1180,
      margin: '0 auto',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ri-eyebrow",
    style: {
      color: 'var(--gold-300)'
    }
  }, "INVITE-ONLY CREATOR MARKETPLACE"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 76,
      lineHeight: 0.98,
      margin: '14px 0 0',
      color: '#fff'
    }
  }, "Be ", /*#__PURE__*/React.createElement("span", {
    className: "ri-foil"
  }, "Rare.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 19,
      maxWidth: 520,
      marginTop: 18,
      color: '#E6DAEC'
    }
  }, "Build a storefront, drop print-on-demand, physical, and digital work, and bring your people with you. Your store, your rules."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 28
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "gold",
    size: "lg",
    rightIcon: /*#__PURE__*/React.createElement(I, {
      n: "arrow-right"
    }),
    onClick: onOpenStore
  }, "Claim your invite"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    style: {
      background: 'rgba(255,255,255,0.08)',
      color: '#fff',
      borderColor: 'rgba(255,255,255,0.25)'
    }
  }, "Explore drops")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 28,
      marginTop: 36,
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: '#C9BAD2'
    }
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", {
    style: {
      color: '#fff',
      fontSize: 16
    }
  }, "105K"), " \xA0followers"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", {
    style: {
      color: '#fff',
      fontSize: 16
    }
  }, "6"), " \xA0store themes"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", {
    style: {
      color: '#fff',
      fontSize: 16
    }
  }, "3"), " \xA0product types")))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1180,
      margin: '0 auto',
      padding: '36px 28px 8px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ri-eyebrow",
    style: {
      marginBottom: 14
    }
  }, "FEATURED CREATORS"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 26,
      overflowX: 'auto',
      paddingBottom: 8
    }
  }, CREATORS.map(c => /*#__PURE__*/React.createElement("button", {
    key: c.id,
    onClick: () => onOpenStore(c.id),
    style: {
      border: 'none',
      background: 'transparent',
      cursor: 'pointer',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 8,
      minWidth: 84
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: c.name,
    size: "xl",
    ring: c.verified
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 13,
      color: 'var(--text)'
    }
  }, c.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-subtle)'
    }
  }, c.followers))))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1180,
      margin: '0 auto',
      padding: '24px 28px 64px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 28
    }
  }, "Rare drops"), /*#__PURE__*/React.createElement(Tabs, {
    value: filter,
    onChange: setFilter,
    tabs: [{
      id: 'all',
      label: 'All'
    }, {
      id: 'pod',
      label: 'POD'
    }, {
      id: 'physical',
      label: 'Physical'
    }, {
      id: 'digital',
      label: 'Digital'
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 20
    }
  }, shown.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.id,
    interactive: true,
    featured: p.rare,
    padding: "0",
    onClick: () => onOpenProduct(p.id),
    style: {
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(ArtTile, {
    seed: p.seed,
    ratio: "4 / 3",
    radius: "0",
    label: p.title.split(' ')[0]
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 10,
      left: 10
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: p.tag === 'Digital' ? 'brand' : p.tag === 'Physical' ? 'gold' : 'neutral',
    solid: false
  }, p.tag)), p.rare && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 10,
      right: 10
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "gold",
    dot: true,
    solid: true
  }, "Rare"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 16px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 16,
      letterSpacing: '-0.01em'
    }
  }, p.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, p.creator)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      color: 'var(--gold-700)'
    }
  }, "$", p.price)), p.rare && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement(EditionTag, {
    code: p.edition,
    total: p.total
  }))))))));
}
window.DiscoverScreen = DiscoverScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/DiscoverScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/storefront/ProductDetail.jsx
try { (() => {
// Product detail + claim flow.
function ProductDetail({
  productId = 'p2',
  onBack
}) {
  const {
    Button,
    Badge,
    Card,
    Avatar,
    EditionTag
  } = window.RareImageryDesignSystem_12274b;
  const {
    ArtTile,
    PRODUCTS
  } = window;
  const p = PRODUCTS.find(x => x.id === productId) || PRODUCTS[0];
  const [claimed, setClaimed] = React.useState(false);
  const I = ({
    n,
    s = 16
  }) => /*#__PURE__*/React.createElement("i", {
    "data-lucide": n,
    style: {
      width: s,
      height: s
    }
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1080,
      margin: '0 auto',
      padding: '20px 28px 64px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      border: 'none',
      background: 'transparent',
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(I, {
    n: "chevron-left"
  }), " Back"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 40,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(ArtTile, {
    seed: p.seed,
    ratio: "1 / 1",
    label: p.title.split(' ')[0],
    style: {
      boxShadow: p.rare ? 'var(--glow-gold)' : 'var(--shadow-lg)'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: p.tag === 'Digital' ? 'brand' : 'gold'
  }, p.tag), p.rare && /*#__PURE__*/React.createElement(Badge, {
    tone: "gold",
    dot: true,
    solid: true
  }, "Rare drop")), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 38,
      lineHeight: 1.05
    }
  }, p.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: p.creator,
    size: "sm",
    ring: true
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-muted)'
    }
  }, "by ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text)'
    }
  }, p.creator))), p.rare && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement(EditionTag, {
    code: p.edition,
    total: p.total
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 34,
      fontWeight: 700,
      marginTop: 22
    }
  }, "$", p.price), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 22
    }
  }, claimed ? /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    leftIcon: /*#__PURE__*/React.createElement(I, {
      n: "check",
      s: 18
    }),
    fullWidth: true,
    disabled: true
  }, "Added to vault") : /*#__PURE__*/React.createElement(Button, {
    variant: "gold",
    size: "lg",
    leftIcon: /*#__PURE__*/React.createElement(I, {
      n: "sparkles",
      s: 18
    }),
    fullWidth: true,
    onClick: () => setClaimed(true)
  }, p.tag === 'Digital' ? 'Buy & download' : 'Claim this drop'), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "lg",
    "aria-label": "Save"
  }, /*#__PURE__*/React.createElement(I, {
    n: "bookmark",
    s: 18
  }))), claimed && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 14,
      color: 'var(--success-600)',
      fontSize: 13,
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement(I, {
    n: "check-circle"
  }), " Secured. Check your vault for the receipt."), /*#__PURE__*/React.createElement(Card, {
    padding: "var(--space-4)",
    style: {
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ri-eyebrow",
    style: {
      marginBottom: 12
    }
  }, "DETAILS"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      fontSize: 14
    }
  }, [['Type', p.type], ['Edition', p.rare ? `№ ${p.edition} / ${p.total}` : 'Open edition'], ['Fulfillment', p.type === 'POD' ? 'Printful' : p.type === 'Digital' ? 'Instant download' : 'Ships in 3–5 days'], ['Creator cut', '85%']].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      borderBottom: '1px solid var(--border)',
      paddingBottom: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontFamily: k === 'Edition' ? 'var(--font-mono)' : 'inherit'
    }
  }, v))))))));
}
window.ProductDetail = ProductDetail;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/ProductDetail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/storefront/StorePlayer.jsx
try { (() => {
// StorePlayer — the MySpace-era CRT music player. Dark retro aesthetic with
// scanlines + glow in brand purple/gold. Cosmetic recreation (fake playback).
function StorePlayer({
  track = 'Hound Beats — Intro',
  artist = 'Bud Hound',
  accent = '#D4AF37'
}) {
  const [playing, setPlaying] = React.useState(false);
  const [t, setT] = React.useState(42);
  React.useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => setT(x => (x + 1) % 198), 1000);
    return () => clearInterval(id);
  }, [playing]);
  const fmt = s => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  const pct = t / 198 * 100;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
      background: 'radial-gradient(120% 120% at 30% 0%, #261A2B 0%, #100912 70%)',
      border: '1px solid color-mix(in srgb, var(--gold-500) 30%, transparent)',
      boxShadow: '0 0 0 1px rgba(0,0,0,0.4), 0 18px 40px rgba(0,0,0,0.5)',
      padding: '16px 18px',
      color: '#ECD9F0',
      fontFamily: 'var(--font-mono)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      pointerEvents: 'none',
      opacity: 0.5,
      mixBlendMode: 'overlay',
      backgroundImage: 'repeating-linear-gradient(0deg, rgba(255,255,255,0.08) 0 1px, transparent 1px 3px)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: '50%',
      flexShrink: 0,
      background: `radial-gradient(circle at 50% 50%, ${accent} 0 30%, #2C1033 32% 60%, ${accent} 62% 64%, #160D1A 66%)`,
      boxShadow: `0 0 18px ${accent}80`,
      animation: playing ? 'ri-spin 4s linear infinite' : 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      letterSpacing: '0.2em',
      color: accent,
      textTransform: 'uppercase'
    }
  }, "\u25C9 Now Playing"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: '#fff',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      marginTop: 3
    }
  }, track), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#B6A8C0'
    }
  }, artist)), /*#__PURE__*/React.createElement("button", {
    onClick: () => setPlaying(p => !p),
    "aria-label": playing ? 'Pause' : 'Play',
    style: {
      width: 42,
      height: 42,
      borderRadius: '50%',
      flexShrink: 0,
      cursor: 'pointer',
      border: `1.5px solid ${accent}`,
      background: 'rgba(212,175,55,0.12)',
      color: accent,
      fontSize: 16,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, playing ? '❚❚' : '►')), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginTop: 14,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: '#B6A8C0'
    }
  }, fmt(t)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 4,
      borderRadius: 4,
      background: 'rgba(255,255,255,0.12)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: pct + '%',
      height: '100%',
      background: accent,
      boxShadow: `0 0 8px ${accent}`
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: '#B6A8C0'
    }
  }, "3:18")));
}
window.StorePlayer = StorePlayer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/StorePlayer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/storefront/TopNav.jsx
try { (() => {
// Storefront top navigation.
function TopNav({
  route,
  onNav,
  onOpenStore
}) {
  const {
    Button,
    Avatar,
    Input
  } = window.RareImageryDesignSystem_12274b;
  const I = ({
    n,
    s = 18
  }) => /*#__PURE__*/React.createElement("i", {
    "data-lucide": n,
    style: {
      width: s,
      height: s
    }
  });
  const links = [['discover', 'Discover'], ['creators', 'Creators'], ['drops', 'Drops']];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 20,
      display: 'flex',
      alignItems: 'center',
      gap: 24,
      padding: '0 28px',
      height: 64,
      background: 'color-mix(in srgb, var(--bg) 86%, transparent)',
      backdropFilter: 'saturate(140%) blur(10px)',
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => onNav('discover'),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      cursor: 'pointer',
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-monogram.svg",
    width: "30",
    height: "30",
    alt: ""
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 18,
      letterSpacing: '-0.02em',
      color: 'var(--text)'
    }
  }, "Rare", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--gold-700)'
    }
  }, "Imagery"))), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 4
    }
  }, links.map(([id, label]) => /*#__PURE__*/React.createElement("button", {
    key: id,
    onClick: () => onNav(id),
    style: {
      border: 'none',
      background: 'transparent',
      cursor: 'pointer',
      padding: '8px 12px',
      fontFamily: 'var(--font-display)',
      fontSize: 14,
      fontWeight: 600,
      borderRadius: 'var(--radius-sm)',
      color: route === id ? 'var(--brand)' : 'var(--text-muted)'
    }
  }, label))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      maxWidth: 320
    }
  }, /*#__PURE__*/React.createElement(Input, {
    leftIcon: /*#__PURE__*/React.createElement(I, {
      n: "search",
      s: 16
    }),
    placeholder: "Search creators, drops\u2026",
    size: "sm"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "gold",
    size: "sm",
    leftIcon: /*#__PURE__*/React.createElement(I, {
      n: "store",
      s: 16
    }),
    onClick: onOpenStore
  }, "Open store"), /*#__PURE__*/React.createElement(Avatar, {
    name: "Robert R",
    size: "sm",
    ring: true
  })));
}
window.TopNav = TopNav;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/TopNav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/storefront/kit.jsx
try { (() => {
// Shared storefront helpers + fake data. Exports to window for sibling babel scripts.
const {
  EditionTag,
  Badge
} = window.RareImageryDesignSystem_12274b;

// Branded placeholder "art" tile — deterministic purple/gold/ink gradient + grain.
// (Stand-in for real creator artwork; no external images used.)
function ArtTile({
  seed = 0,
  label,
  ratio = '1 / 1',
  radius = 'var(--radius-md)',
  children,
  style
}) {
  const palettes = ['linear-gradient(150deg,#41184A,#7B2D8E 60%,#A857BB)', 'linear-gradient(150deg,#1E1322,#561F62 70%,#D4AF37)', 'linear-gradient(150deg,#2C1033,#6A2679 55%,#E2C159)', 'linear-gradient(150deg,#160D1A,#41184A 60%,#927422)', 'linear-gradient(150deg,#342440,#7B2D8E)', 'linear-gradient(150deg,#100912,#2C1033 50%,#B8942A)'];
  return /*#__PURE__*/React.createElement("div", {
    className: "ri-grain",
    style: {
      position: 'relative',
      width: '100%',
      aspectRatio: ratio,
      background: palettes[seed % palettes.length],
      borderRadius: radius,
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      letterSpacing: '0.18em',
      color: 'rgba(255,255,255,0.32)',
      textTransform: 'uppercase',
      fontWeight: 700
    }
  }, label), children);
}
const CREATORS = [{
  id: 'budhound',
  name: 'Bud Hound',
  handle: '@budhound',
  followers: '105K',
  theme: '#7B2D8E',
  verified: true
}, {
  id: 'nyx',
  name: 'Nyx Vega',
  handle: '@nyxvega',
  followers: '42.1K',
  theme: '#B8942A',
  verified: true
}, {
  id: 'oro',
  name: 'Studio Oro',
  handle: '@studio.oro',
  followers: '18.7K',
  theme: '#561F62',
  verified: false
}, {
  id: 'crt',
  name: 'CRT Kid',
  handle: '@crtkid',
  followers: '9.3K',
  theme: '#463253',
  verified: false
}, {
  id: 'mara',
  name: 'Mara Sol',
  handle: '@marasol',
  followers: '63.4K',
  theme: '#927422',
  verified: true
}];
const PRODUCTS = [{
  id: 'p1',
  title: 'Neon Hound Tee',
  creator: 'Bud Hound',
  type: 'POD',
  price: '38.00',
  seed: 0,
  edition: '001',
  total: '∞',
  rare: false,
  tag: 'POD'
}, {
  id: 'p2',
  title: 'Foil Sticker Pack',
  creator: 'Nyx Vega',
  type: 'Physical',
  price: '12.00',
  seed: 1,
  edition: '044',
  total: '250',
  rare: true,
  tag: 'Physical'
}, {
  id: 'p3',
  title: 'CRT Dreams (Wallpaper Set)',
  creator: 'CRT Kid',
  type: 'Digital',
  price: '9.00',
  seed: 5,
  edition: '—',
  total: '∞',
  rare: false,
  tag: 'Digital'
}, {
  id: 'p4',
  title: 'Rare Vault Hoodie',
  creator: 'Studio Oro',
  type: 'POD',
  price: '64.00',
  seed: 3,
  edition: '007',
  total: '100',
  rare: true,
  tag: 'POD'
}, {
  id: 'p5',
  title: 'Gold Edition Print',
  creator: 'Mara Sol',
  type: 'Physical',
  price: '120.00',
  seed: 2,
  edition: '012',
  total: '50',
  rare: true,
  tag: 'Physical'
}, {
  id: 'p6',
  title: 'Hound Beats Vol. 1',
  creator: 'Bud Hound',
  type: 'Digital',
  price: '6.00',
  seed: 4,
  edition: '—',
  total: '∞',
  rare: false,
  tag: 'Digital'
}];
Object.assign(window, {
  ArtTile,
  CREATORS,
  PRODUCTS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/kit.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/ios-frame.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// iOS.jsx — Simplified iOS 26 (Liquid Glass) device frame
// Based on the iOS 26 UI Kit + Figma status bar spec. No assets, no deps.
// Exports (to window): IOSDevice, IOSStatusBar, IOSNavBar, IOSGlassPill, IOSList, IOSListRow, IOSKeyboard
//
// Usage — wrap your screen content in <IOSDevice> to get the bezel, status bar
// and home indicator (props: title, dark, keyboard):
//
//   <IOSDevice title="Settings">
//     ...your screen content...
//   </IOSDevice>
//   <IOSDevice dark title="Search" keyboard>…</IOSDevice>
/* END USAGE */

// ─────────────────────────────────────────────────────────────
// Status bar
// ─────────────────────────────────────────────────────────────
function IOSStatusBar({
  dark = false,
  time = '9:41'
}) {
  const c = dark ? '#fff' : '#000';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 154,
      alignItems: 'center',
      justifyContent: 'center',
      padding: '21px 24px 19px',
      boxSizing: 'border-box',
      position: 'relative',
      zIndex: 20,
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      paddingTop: 1.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: '-apple-system, "SF Pro", system-ui',
      fontWeight: 590,
      fontSize: 17,
      lineHeight: '22px',
      color: c
    }
  }, time)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 7,
      paddingTop: 1,
      paddingRight: 1
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "19",
    height: "12",
    viewBox: "0 0 19 12"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "7.5",
    width: "3.2",
    height: "4.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "4.8",
    y: "5",
    width: "3.2",
    height: "7",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "9.6",
    y: "2.5",
    width: "3.2",
    height: "9.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14.4",
    y: "0",
    width: "3.2",
    height: "12",
    rx: "0.7",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "12",
    viewBox: "0 0 17 12"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z",
    fill: c
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "8.5",
    cy: "10.5",
    r: "1.5",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "27",
    height: "13",
    viewBox: "0 0 27 13"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0.5",
    y: "0.5",
    width: "23",
    height: "12",
    rx: "3.5",
    stroke: c,
    strokeOpacity: "0.35",
    fill: "none"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "20",
    height: "9",
    rx: "2",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M25 4.5V8.5C25.8 8.2 26.5 7.2 26.5 6.5C26.5 5.8 25.8 4.8 25 4.5Z",
    fill: c,
    fillOpacity: "0.4"
  }))));
}

// ─────────────────────────────────────────────────────────────
// Liquid glass pill — blur + tint + shine
// ─────────────────────────────────────────────────────────────
function IOSGlassPill({
  children,
  dark = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 44,
      minWidth: 44,
      borderRadius: 9999,
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: dark ? '0 2px 6px rgba(0,0,0,0.35), 0 6px 16px rgba(0,0,0,0.2)' : '0 1px 3px rgba(0,0,0,0.07), 0 3px 10px rgba(0,0,0,0.06)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.28)' : 'rgba(255,255,255,0.5)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15), inset -1px -1px 1px rgba(255,255,255,0.08)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      display: 'flex',
      alignItems: 'center',
      padding: '0 4px'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Navigation bar — glass pills + large title
// ─────────────────────────────────────────────────────────────
function IOSNavBar({
  title = 'Title',
  dark = false,
  trailingIcon = true
}) {
  const muted = dark ? 'rgba(255,255,255,0.6)' : '#404040';
  const text = dark ? '#fff' : '#000';
  const pillIcon = content => /*#__PURE__*/React.createElement(IOSGlassPill, {
    dark: dark
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, content));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      paddingTop: 62,
      paddingBottom: 10,
      position: 'relative',
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 16px'
    }
  }, pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "20",
    viewBox: "0 0 12 20",
    fill: "none",
    style: {
      marginLeft: -1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M10 2L2 10l8 8",
    stroke: muted,
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), trailingIcon && pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "6",
    viewBox: "0 0 22 6"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "3",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "19",
    cy: "3",
    r: "2.5",
    fill: muted
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      fontFamily: '-apple-system, system-ui',
      fontSize: 34,
      fontWeight: 700,
      lineHeight: '41px',
      color: text,
      letterSpacing: 0.4
    }
  }, title));
}

// ─────────────────────────────────────────────────────────────
// Grouped list (inset card, r:26) + row (52px)
// ─────────────────────────────────────────────────────────────
function IOSListRow({
  title,
  detail,
  icon,
  chevron = true,
  isLast = false,
  dark = false
}) {
  const text = dark ? '#fff' : '#000';
  const sec = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const ter = dark ? 'rgba(235,235,245,0.3)' : 'rgba(60,60,67,0.3)';
  const sep = dark ? 'rgba(84,84,88,0.65)' : 'rgba(60,60,67,0.12)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      minHeight: 52,
      padding: '0 16px',
      position: 'relative',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      letterSpacing: -0.43
    }
  }, icon && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 7,
      background: icon,
      marginRight: 12,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      color: text
    }
  }, title), detail && /*#__PURE__*/React.createElement("span", {
    style: {
      color: sec,
      marginRight: 6
    }
  }, detail), chevron && /*#__PURE__*/React.createElement("svg", {
    width: "8",
    height: "14",
    viewBox: "0 0 8 14",
    style: {
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1 1l6 6-6 6",
    stroke: ter,
    strokeWidth: "2",
    fill: "none",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })), !isLast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      right: 0,
      left: icon ? 58 : 16,
      height: 0.5,
      background: sep
    }
  }));
}
function IOSList({
  header,
  children,
  dark = false
}) {
  const hc = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const bg = dark ? '#1C1C1E' : '#fff';
  return /*#__PURE__*/React.createElement("div", null, header && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: '-apple-system, system-ui',
      fontSize: 13,
      color: hc,
      textTransform: 'uppercase',
      padding: '8px 36px 6px',
      letterSpacing: -0.08
    }
  }, header), /*#__PURE__*/React.createElement("div", {
    style: {
      background: bg,
      borderRadius: 26,
      margin: '0 16px',
      overflow: 'hidden'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Device frame
// ─────────────────────────────────────────────────────────────
function IOSDevice({
  children,
  width = 402,
  height = 874,
  dark = false,
  title,
  keyboard = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width,
      height,
      borderRadius: 48,
      overflow: 'hidden',
      position: 'relative',
      background: dark ? '#000' : '#F2F2F7',
      boxShadow: '0 40px 80px rgba(0,0,0,0.18), 0 0 0 1px rgba(0,0,0,0.12)',
      fontFamily: '-apple-system, system-ui, sans-serif',
      WebkitFontSmoothing: 'antialiased'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 11,
      left: '50%',
      transform: 'translateX(-50%)',
      width: 126,
      height: 37,
      borderRadius: 24,
      background: '#000',
      zIndex: 50
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement(IOSStatusBar, {
    dark: dark
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column'
    }
  }, title !== undefined && /*#__PURE__*/React.createElement(IOSNavBar, {
    title: title,
    dark: dark
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto'
    }
  }, children), keyboard && /*#__PURE__*/React.createElement(IOSKeyboard, {
    dark: dark
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      zIndex: 60,
      height: 34,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'flex-end',
      paddingBottom: 8,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 139,
      height: 5,
      borderRadius: 100,
      background: dark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.25)'
    }
  })));
}

// ─────────────────────────────────────────────────────────────
// Keyboard — iOS 26 liquid glass
// ─────────────────────────────────────────────────────────────
function IOSKeyboard({
  dark = false
}) {
  const glyph = dark ? 'rgba(255,255,255,0.7)' : '#595959';
  const sugg = dark ? 'rgba(255,255,255,0.6)' : '#333';
  const keyBg = dark ? 'rgba(255,255,255,0.22)' : 'rgba(255,255,255,0.85)';

  // special-key icons
  const icons = {
    shift: /*#__PURE__*/React.createElement("svg", {
      width: "19",
      height: "17",
      viewBox: "0 0 19 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M9.5 1L1 9.5h4.5V16h8V9.5H18L9.5 1z",
      fill: glyph
    })),
    del: /*#__PURE__*/React.createElement("svg", {
      width: "23",
      height: "17",
      viewBox: "0 0 23 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M7 1h13a2 2 0 012 2v11a2 2 0 01-2 2H7l-6-7.5L7 1z",
      fill: "none",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinejoin: "round"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M10 5l7 7M17 5l-7 7",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinecap: "round"
    })),
    ret: /*#__PURE__*/React.createElement("svg", {
      width: "20",
      height: "14",
      viewBox: "0 0 20 14"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M18 1v6H4m0 0l4-4M4 7l4 4",
      fill: "none",
      stroke: "#fff",
      strokeWidth: "1.8",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }))
  };
  const key = (content, {
    w,
    flex,
    ret,
    fs = 25,
    k
  } = {}) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      height: 42,
      borderRadius: 8.5,
      flex: flex ? 1 : undefined,
      width: w,
      minWidth: 0,
      background: ret ? '#08f' : keyBg,
      boxShadow: '0 1px 0 rgba(0,0,0,0.075)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: '-apple-system, "SF Compact", system-ui',
      fontSize: fs,
      fontWeight: 458,
      color: ret ? '#fff' : glyph
    }
  }, content);
  const row = (keys, pad = 0) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      justifyContent: 'center',
      padding: `0 ${pad}px`
    }
  }, keys.map(l => key(l, {
    flex: true,
    k: l
  })));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 15,
      borderRadius: 27,
      overflow: 'hidden',
      padding: '11px 0 2px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      boxShadow: dark ? '0 -2px 20px rgba(0,0,0,0.09)' : '0 -1px 6px rgba(0,0,0,0.018), 0 -3px 20px rgba(0,0,0,0.012)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.14)' : 'rgba(255,255,255,0.25)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'center',
      padding: '8px 22px 13px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, ['"The"', 'the', 'to'].map((w, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: 25,
      background: '#ccc',
      opacity: 0.3
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      textAlign: 'center',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      color: sugg,
      letterSpacing: -0.43,
      lineHeight: '22px'
    }
  }, w)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 13,
      padding: '0 6.5px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, row(['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p']), row(['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'], 20), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14.25,
      alignItems: 'center'
    }
  }, key(icons.shift, {
    w: 45,
    k: 'shift'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      flex: 1
    }
  }, ['z', 'x', 'c', 'v', 'b', 'n', 'm'].map(l => key(l, {
    flex: true,
    k: l
  }))), key(icons.del, {
    w: 45,
    k: 'del'
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center'
    }
  }, key('ABC', {
    w: 92.25,
    fs: 18,
    k: 'abc'
  }), key('', {
    flex: true,
    k: 'space'
  }), key(icons.ret, {
    w: 92.25,
    ret: true,
    k: 'ret'
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 56,
      width: '100%',
      position: 'relative'
    }
  }));
}
Object.assign(window, {
  IOSDevice,
  IOSStatusBar,
  IOSNavBar,
  IOSGlassPill,
  IOSList,
  IOSListRow,
  IOSKeyboard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/ios-frame.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/screens.jsx
try { (() => {
// RareImagery Studio — iOS app screens (cosmetic SwiftUI recreation).
// Dark "vault" theme. Composes DS primitives inside the iOS device frame.
const DS = window.RareImageryDesignSystem_12274b;
const Icon = ({
  n,
  s = 22,
  c
}) => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n,
  style: {
    width: s,
    height: s,
    color: c
  }
});
const money = n => '$' + n.toLocaleString('en-US', {
  minimumFractionDigits: 2
});

// ---------- Shared chrome ----------
function AppHeader({
  title,
  sub,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 20px 14px',
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, sub && /*#__PURE__*/React.createElement("div", {
    className: "ri-eyebrow",
    style: {
      color: 'var(--gold-400)',
      marginBottom: 6
    }
  }, sub), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 30,
      color: 'var(--text)',
      letterSpacing: '-0.02em'
    }
  }, title)), action);
}

// ---------- Dashboard ----------
function StudioDashboard() {
  const {
    Card,
    Badge,
    EditionTag
  } = DS;
  const stats = [{
    label: 'Revenue · 30d',
    value: money(4280),
    delta: '+18%',
    up: true
  }, {
    label: 'Drops live',
    value: '12',
    delta: '3 rare',
    up: true
  }, {
    label: 'Followers',
    value: '105K',
    delta: '+1.2K',
    up: true
  }];
  const activity = [{
    who: 'Nyx Vega',
    what: 'claimed Foil Sticker Pack',
    t: '2m',
    tone: 'gold'
  }, {
    who: 'Mara Sol',
    what: 'co-signed your drop',
    t: '14m',
    tone: 'brand'
  }, {
    who: 'CRT Kid',
    what: 'started following',
    t: '1h',
    tone: 'neutral'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 54
    }
  }, /*#__PURE__*/React.createElement(AppHeader, {
    sub: "GOOD MORNING, ROBERT",
    title: "Studio"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12,
      padding: '0 16px'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "14px",
    style: {
      gridColumn: '1 / -1',
      background: 'var(--brand-wash)',
      border: 'none',
      color: '#fff',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ri-grain",
    style: {
      position: 'absolute',
      inset: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ri-eyebrow",
    style: {
      color: 'var(--gold-300)'
    }
  }, stats[0].label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 38,
      fontWeight: 700,
      color: '#fff',
      marginTop: 4
    }
  }, stats[0].value), /*#__PURE__*/React.createElement(Badge, {
    tone: "gold",
    dot: true,
    solid: true,
    style: {
      marginTop: 6
    }
  }, stats[0].delta, " vs last month"))), stats.slice(1).map(s => /*#__PURE__*/React.createElement(Card, {
    key: s.label,
    padding: "14px"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ri-eyebrow"
  }, s.label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 26,
      fontWeight: 700,
      color: 'var(--text)',
      marginTop: 4
    }
  }, s.value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--success-500)',
      fontWeight: 600,
      marginTop: 2
    }
  }, s.delta)))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '22px 20px 8px'
    },
    className: "ri-eyebrow"
  }, "RECENT ACTIVITY"), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, activity.map((a, i) => /*#__PURE__*/React.createElement(Card, {
    key: i,
    padding: "12px 14px",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(DS.Avatar, {
    name: a.who,
    size: "sm",
    ring: a.tone === 'gold'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      fontSize: 14,
      color: 'var(--text)'
    }
  }, /*#__PURE__*/React.createElement("b", null, a.who), " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, a.what)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-subtle)'
    }
  }, a.t)))));
}

// ---------- Drops ----------
function StudioDrops() {
  const {
    Card,
    Badge,
    EditionTag,
    Button
  } = DS;
  const drops = [{
    title: 'Foil Sticker Pack',
    type: 'Physical',
    status: 'Live',
    tone: 'success',
    edition: '044',
    total: '250',
    seed: 1,
    rare: true
  }, {
    title: 'Rare Vault Hoodie',
    type: 'POD',
    status: 'Live',
    tone: 'success',
    edition: '007',
    total: '100',
    seed: 3,
    rare: true
  }, {
    title: 'CRT Dreams',
    type: 'Digital',
    status: 'Draft',
    tone: 'neutral',
    edition: '—',
    total: '∞',
    seed: 5,
    rare: false
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 54
    }
  }, /*#__PURE__*/React.createElement(AppHeader, {
    sub: "12 LIVE \xB7 3 RARE",
    title: "Drops",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "gold",
      size: "sm",
      leftIcon: /*#__PURE__*/React.createElement(Icon, {
        n: "plus",
        s: 16
      })
    }, "New")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, drops.map((d, i) => /*#__PURE__*/React.createElement(Card, {
    key: i,
    featured: d.rare,
    padding: "12px",
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(window.ArtTile, {
    seed: d.seed,
    ratio: "1 / 1",
    label: "",
    style: {
      width: 60,
      height: 60,
      flexShrink: 0,
      borderRadius: 'var(--radius-sm)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 16,
      color: 'var(--text)'
    }
  }, d.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, d.type), /*#__PURE__*/React.createElement(Badge, {
    tone: d.tone,
    dot: true
  }, d.status))), d.rare && /*#__PURE__*/React.createElement(EditionTag, {
    code: d.edition,
    total: d.total
  })))));
}

// ---------- Rare Circle ----------
function StudioCircle() {
  const {
    Card,
    Badge,
    Button,
    Avatar
  } = DS;
  const [reqs, setReqs] = React.useState([{
    who: 'Mara Sol',
    drop: 'Gold Edition Print',
    state: 'pending'
  }, {
    who: 'Studio Oro',
    drop: 'Rare Vault Hoodie',
    state: 'pending'
  }]);
  const act = (i, state) => setReqs(r => r.map((x, j) => j === i ? {
    ...x,
    state
  } : x));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 54
    }
  }, /*#__PURE__*/React.createElement(AppHeader, {
    sub: "CO-SIGN BEFORE YOU DROP",
    title: "Rare Circle"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 20px 14px',
      fontSize: 13,
      color: 'var(--text-muted)',
      lineHeight: 1.5
    }
  }, "Your private network of trusted creators. Request a co-sign before publishing a drop to your circle."), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 20px 8px'
    },
    className: "ri-eyebrow"
  }, "CO-SIGN REQUESTS"), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, reqs.map((r, i) => /*#__PURE__*/React.createElement(Card, {
    key: i,
    padding: "14px"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: r.who,
    size: "md",
    ring: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      color: 'var(--text)'
    }
  }, r.who), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "wants you to co-sign ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text)'
    }
  }, r.drop)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 14
    }
  }, r.state === 'pending' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
    variant: "gold",
    size: "sm",
    fullWidth: true,
    onClick: () => act(i, 'signed')
  }, "Co-sign"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => act(i, 'passed')
  }, "Pass")) : /*#__PURE__*/React.createElement(Badge, {
    tone: r.state === 'signed' ? 'success' : 'neutral',
    dot: true
  }, r.state === 'signed' ? 'Co-signed' : 'Passed'))))));
}
Object.assign(window, {
  StudioDashboard,
  StudioDrops,
  StudioCircle,
  AppHeader,
  Icon
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/screens.jsx", error: String((e && e.message) || e) }); }

__ds_ns.EditionTag = __ds_scope.EditionTag;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
