# RareImagery Design System

> **Be Rare.** — the design system for RareImagery, an invite-only creator marketplace.
> Brand purple `#7B2D8E` · brand gold `#D4AF37` · mascot **Bud Hound**.

This project is a self-contained design system: brand foundations, design tokens, reusable React UI primitives, and high-fidelity UI kit recreations of the real products. A compiler bundles the components into a runtime library (`_ds_bundle.js`) and indexes the tokens; consumers link a single `styles.css`.

---

## 1. What RareImagery is

RareImagery (`@RareImagery`, ~105k X followers, name held ~20 years) is an **invite-only creator marketplace**. Creators get their own storefront on a subdomain and sell three kinds of product:

- **POD** — print-on-demand, fulfilled via Printful
- **Physical** — custom physical goods
- **Digital** — downloads

Stores can pick among **six themes**, including a MySpace-style retro option, and run a built-in **StorePlayer** (a retro-CRT music player). The brand voice is confident, warm, and a touch exclusive — "rare" is the organizing idea: editions, drops, catalog numbers, co-signs.

### Products represented in this system
1. **Storefront** (`ui_kits/storefront/`) — the public web marketplace (the `x-store-next` Next.js frontend): discover creators & drops, browse a creator's store with the StorePlayer, view a product and claim a drop.
2. **RareImagery Studio** (`ui_kits/studio/`) — the native iOS Swift companion app: creator dashboard, drops management, and the **Rare Circle** social co-signing feature.

### Source material
This system was built from the **RareImagery Master Project Archive** (a written brand/architecture snapshot, 2026-06-24). The live products live in private repos not accessible here:
- `github.com/rareimagery/x-store-drupal` — headless Drupal 11 backend
- `github.com/rareimagery/x-store-next` — Next.js storefront
- `github.com/rareimagery/rareimagery-studio` — iOS Swift app

> ⚠️ **No live codebase, Figma, fonts, logo, or mascot art were available.** Visual decisions here are a faithful interpretation of the documented brand (colors, tagline, retro/premium positioning), not a pixel copy of shipping UI. See **Caveats** at the bottom — please send real assets so this can be tightened to production fidelity.

---

## 2. Content fundamentals (voice & copy)

The voice is **confident, warm, and quietly exclusive** — premium without being cold. "Rare" is the throughline.

- **Tagline:** `Be Rare.` — two words, period included. The hero word "Rare." is often set in **gold foil**.
- **Person:** Speaks **to the creator** ("Build a storefront", "bring your people with you", "Your store, your rules"). Second person, active voice.
- **Casing:** Sentence case for body and most UI. **Mono UPPERCASE with wide tracking** for eyebrow/catalog labels only (`INVITE-ONLY MARKETPLACE`, `EDITION № 001 / 250`).
- **Length:** Short lines. Headlines are 2–5 words. No marketing bloat.
- **Vocabulary:** *drop, claim, vault, edition, rare, co-sign, circle, creator, store.* Buying a rare item is "**claim this drop**"; buying digital is "**buy & download**." A saved/owned item lives in your "**vault**."
- **Numbers:** Set in mono. Follower counts and prices read like catalog data (`$24.00`, `105K`, `№ 044 / 250`).
- **Emoji:** Effectively none in product UI. The retro/CRT surfaces use a couple of unicode glyphs as controls (`►`, `❚❚`, `◉`) — characterful, not decorative emoji.
- **Tone test:** "Confident, warm, a little exclusive. Short lines. Never shouty."

Examples:
- Hero: **"Be Rare."** / "An invite-only marketplace for rare creators."
- CTA: "Claim your invite" · "Claim this drop" · "Open store"
- Empty/secured state: "Secured. Check your vault for the receipt."

---

## 3. Visual foundations

The aesthetic is **"Rare Vault"** — premium collectible meets a retro-digital streak.

**Color.** Brand **purple `#7B2D8E`** is primary; **gold `#D4AF37`** is the accent reserved for *rare / high-value* moments (foil hero words, the single most important CTA, featured cards, verified rings, edition tags). Darks are **purple-tinted "ink"** (`#100912`–`#463253`), never neutral black. Neutrals are warm violet-grays. A dark **`[data-theme="vault"]`** scope flips the semantic tokens for premium dark surfaces (used by the iOS app and hero bands). Status colors are jewel tones tuned to coexist with purple/gold.

**Typography.** Three families:
- **Space Grotesk** (`--font-display`) — headings, hero, UI labels, buttons. Tight tracking (`-0.02 to -0.03em`) at large sizes.
- **Hanken Grotesk** (`--font-body`) — body & long-form, warm and readable.
- **JetBrains Mono** (`--font-mono`) — the brand signature device: catalog codes, edition numbers, prices, eyebrow labels, dev/CRT lineage. Uppercase + `0.16em` tracking for eyebrows.

**Backgrounds.** Mostly clean light surfaces on the storefront; deep **purple-wash** bands (`--brand-wash`, a solid deep-purple gradient — *not* a bluish tech gradient) for heroes. A subtle **film-grain overlay** (`.ri-grain`) sits on dark/hero surfaces and the CRT player for retro texture. The **`--foil`** gold sweep is used sparingly on "rare" words and chips.

**Cards.** Soft, purple-tinted shadows (never neutral gray), `--radius-lg` (16px) corners, a 1px hairline border. Interactive cards **lift -3px** on hover with a larger shadow. **Featured/rare** cards swap to a **gold hairline + gold glow** (`--glow-gold`). Product "art" is shown on collectible-style branded tiles.

**Motion.** Quick and confident. `--dur-fast` (140ms) for hover/press, `--dur-base` (220ms) for lifts. `--ease-out` to settle, `--ease-spring` (slight overshoot) for the Switch knob. Reduced-motion is respected globally. No infinite decorative loops except the CRT player disc while "playing."

**Interaction states.**
- *Hover:* buttons darken to `--brand-hover`/`--gold-hover`; cards lift; ghost/secondary fill with `--surface-sunken`.
- *Press:* buttons nudge `translateY(1px) scale(0.99)` — tactile.
- *Focus:* 2px brand outline, offset 2px; inputs get a 3px `--focus-ring` halo and brand border.
- *Disabled:* 45% opacity, `not-allowed`.

**Borders & dividers.** 1px hairlines from `--border` / `--border-strong`; gold hairlines (`--border-gold`) mark rare items. Radii scale from `--radius-xs` (4) to `--radius-2xl` (30); pills for badges/toggles.

**Imagery vibe.** Creator art reads as **collectible** — deep purple/ink fields with gold highlights, slight grain, catalog/edition framing. Warm, jewel-toned, a little nocturnal.

**Layout.** `--container` 1200px max; 4px spacing grid (`--space-*`). Sticky translucent top nav with blur on the storefront; sticky sidebar (StorePlayer + store meta) on creator stores; iOS device frame + bottom tab bar for Studio.

---

## 4. Iconography

- **System:** [**Lucide**](https://lucide.dev) via CDN (`unpkg.com/lucide`). Clean, consistent ~2px stroke that suits the modern-grotesque type. *(Substitution — no brand icon set was provided. If RareImagery ships its own SVG/icon font, drop it into `assets/` and swap usage.)*
- **Usage:** `<i data-lucide="arrow-right">` then `lucide.createIcons()`. Common glyphs: `arrow-right, sparkles, store, search, plus, check, chevron-left, bookmark, users-round, house, layout-grid, user, external-link`.
- **Sizing:** 16px in buttons/inline, 18–24px standalone and in the iOS tab bar. Color inherits `currentColor`.
- **Brand mark:** `assets/logo-monogram.svg` (rounded-square "R") and `assets/logo-wordmark.svg` — **typographic placeholders**, flagged for replacement.
- **Mascot:** `assets/budhound-placeholder.svg` — a labeled slot only. **Bud Hound art must be supplied.**
- **Unicode as icons:** the retro StorePlayer uses `►`, `❚❚`, `◉` deliberately. Emoji are otherwise avoided.

---

## 5. Index / manifest

**Root**
- `styles.css` — the single entry point consumers link (`@import` list only).
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `radius.css`, `elevation.css`, `motion.css`, `base.css`.
- `assets/` — `logo-wordmark.svg`, `logo-monogram.svg`, `budhound-placeholder.svg` *(all placeholders)*.
- `readme.md` (this file) · `SKILL.md` (Agent-Skill wrapper).

**Components** (`components/<group>/` — `window.RareImageryDesignSystem_12274b.<Name>`)
- `core/` — **Button**, **Badge**
- `forms/` — **Input**, **Switch**
- `data/` — **Card**, **Avatar**
- `navigation/` — **Tabs**
- `brand/` — **EditionTag** (signature catalog/edition chip)

**UI kits**
- `ui_kits/storefront/` — web marketplace: `index.html` (orchestrator) · `TopNav`, `DiscoverScreen`, `CreatorStore`, `ProductDetail`, `StorePlayer` (CRT), `kit.jsx` (data + ArtTile).
- `ui_kits/studio/` — iOS app: `index.html` (orchestrator + tab bar + Profile) · `screens.jsx` (Dashboard, Drops, Rare Circle) · `ios-frame.jsx` (device frame).

**Foundation cards** (Design System tab): `guidelines/*.card.html` — Colors (brand, neutrals, semantic), Type (display, body, mono, scale), Spacing (scale, radius, elevation), Brand (logo, mascot, motifs, voice).

---

## 6. Caveats & how to make this perfect

This was built from a **written brand archive only**. To raise it to production fidelity, please provide:
1. **Real fonts** — current stand-ins are Space Grotesk / Hanken Grotesk / JetBrains Mono. What does RareImagery actually use?
2. **Official logo + wordmark** files (replacing the typographic placeholders).
3. **Bud Hound mascot art** (PNG/SVG) for the placeholder slot.
4. **Storefront & Studio screenshots or repo access** (`x-store-next`, `rareimagery-studio`) so the UI kits match shipping layouts and the six store themes / real StorePlayer.
5. The **brand icon set**, if one exists, to replace Lucide.

The color system, tagline, and overall "rare/premium + retro" direction follow the archive directly and should be close — but the specifics above need your input.
